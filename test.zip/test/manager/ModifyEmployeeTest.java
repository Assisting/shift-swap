/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package manager;

import controller.Employee;
import frontend.Input;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author erik
 */
public class ModifyEmployeeTest
{
    
    public ModifyEmployeeTest()
    {
    }
    
    @Before
    public void setUp()
    {
	Employee testEmp = new Employee("TestEmp", "Test", "Emp", 1,
			    Input.createHash("testemp"), "example@example.com",
			    10.35f);
	Input.addNewEmployee(testEmp);
	
	Input.modifyEmployeeInfo("TestEmp", "John", "Smithe", "eriklabine@gmail.com",
		2, 11.35f);
    }
    
    @After
    public void tearDown()
    {
	Input.removeEmployee("TestEmp");
    }

    @Test
    public void nameChanged() {
	Employee emp = Input.getWorkerInfo("TestEmp");
	Assert.assertEquals("First name not changed", "John", emp.getFirstName());
	Assert.assertEquals("Last name not changed", "Smithe", emp.getLastName());
    }
    
    @Test
    public void emailChanged() {
	Employee emp = Input.getWorkerInfo("TestEmp");
	Assert.assertEquals("Email not changed", "eriklabine@gmail.com", emp.getEmail());
    }
    
    @Test
    public void accessChanged() {
	Employee emp = Input.getWorkerInfo("TestEmp");
	Assert.assertEquals("Access not changed", 2, emp.getAccessLevel());
    }
    
    @Test
    public void wageChanged() {
	Employee emp = Input.getWorkerInfo("TestEmp");
	Assert.assertEquals("Wage not changed", 11.35f, emp.getWage(), 0.01f);
    }
}
