/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package manager;

import controller.Employee;
import frontend.Input;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author erik
 */
public class ModifyEmployeeTest
{
    
    public ModifyEmployeeTest()
    {
    }
    
    @Before
    public void setUp()
    {
	Employee testEmp = new Employee("TestEmp", "Test", "Emp", 1,
			    Input.createHash("testemp"), "example@example.com",
			    10.35f);
	Input.addNewEmployee(testEmp);
	
	Input.modifyEmployeeInfo("TestEmp", "John", "Smithe", "gmail@gmail.com",
		2, 11.35f);
    }
    
    @After
    public void tearDown()
    {
	Input.removeEmployee("TestEmp");
    }

    @Test
    public void nameChanged() {
	Employee emp = Input.getWorkerInfo("TestEmp");
	
	String expectedFirstName = "John";
	String actualFirstName = emp.getFirstName();
	Assert.assertEquals("First name not changed",
		expectedFirstName, actualFirstName);
	
	String expectedLastName = "Smithe";
	String actualLastName = emp.getLastName();
	Assert.assertEquals("Last name not changed",
		expectedLastName, actualLastName);
    }
    
    @Test
    public void emailChanged() {
	Employee emp = Input.getWorkerInfo("TestEmp");
	
	String expectedEmail = "gmail@gmail.com";
	String actualEmail = emp.getEmail();
	Assert.assertEquals("Email not changed", expectedEmail, actualEmail);
    }
    
    @Test
    public void accessChanged() {
	Employee emp = Input.getWorkerInfo("TestEmp");
	
	int expectedAccess = 2;
	int actualAccess = emp.getAccessLevel();
	Assert.assertEquals("Access not changed", expectedAccess, actualAccess);
    }
    
    @Test
    public void wageChanged() {
	Employee emp = Input.getWorkerInfo("TestEmp");
	
	float expectedWage = 11.35f;
	float actualWage = emp.getWage();
	Assert.assertEquals("Wage not changed", expectedWage, actualWage, 0.01f);
    }
}
