/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package manager;

import controller.Employee;
import frontend.Input;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author erik
 */
public class AddEmployeeTest
{
    
    public AddEmployeeTest()
    {
    }
    
    @Before
    public void setUp()
    {
	Employee testEmp = new Employee("TestEmp", "Test", "Emp", 1,
			    Input.createHash("testemp"), "example@example.com",
			    10.35f);
	Input.addNewEmployee(testEmp);
    }
    
    @After
    public void tearDown()
    {
	Input.removeEmployee("TestEmp");
    }
    @Test
    public void usernameExists() 
    {
	Assert.assertFalse("Username not in database",
		Input.isUsernameUnique("TestEmp"));
    }
    
    @Test
    public void usernameAuthenticates()
    {
	Assert.assertTrue("User could not log in",
		Input.authenticate("TestEmp", "testemp"));
    }
}
