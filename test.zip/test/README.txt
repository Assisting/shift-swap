Place the entire "Test" directory in the root directory of your NetBeans project.
