Put the entire "test" directory inside the root directory of your NetBeans project
